package android.support.v4.media;

public class TransportStateListener
{
  public void onPlayingChanged(TransportController paramTransportController) {}
  
  public void onTransportControlsChanged(TransportController paramTransportController) {}
}


/* Location:           C:\Users\Vishal\Desktop\Android\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.media.TransportStateListener
 * JD-Core Version:    0.7.0.1
 */