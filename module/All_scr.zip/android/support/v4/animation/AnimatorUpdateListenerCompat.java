package android.support.v4.animation;

public abstract interface AnimatorUpdateListenerCompat
{
  public abstract void onAnimationUpdate(ValueAnimatorCompat paramValueAnimatorCompat);
}


/* Location:           C:\Users\Vishal\Desktop\Android\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.animation.AnimatorUpdateListenerCompat
 * JD-Core Version:    0.7.0.1
 */