package android.support.v4.view;

import android.view.ViewGroup;

class ViewGroupCompatJellybeanMR2
{
  public static int getLayoutMode(ViewGroup paramViewGroup)
  {
    return paramViewGroup.getLayoutMode();
  }
  
  public static void setLayoutMode(ViewGroup paramViewGroup, int paramInt)
  {
    paramViewGroup.setLayoutMode(paramInt);
  }
}


/* Location:           C:\Users\Vishal\Desktop\Android\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.view.ViewGroupCompatJellybeanMR2
 * JD-Core Version:    0.7.0.1
 */