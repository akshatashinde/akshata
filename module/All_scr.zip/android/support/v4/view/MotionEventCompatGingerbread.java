package android.support.v4.view;

import android.view.MotionEvent;

class MotionEventCompatGingerbread
{
  public static int getSource(MotionEvent paramMotionEvent)
  {
    return paramMotionEvent.getSource();
  }
}


/* Location:           C:\Users\Vishal\Desktop\Android\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.view.MotionEventCompatGingerbread
 * JD-Core Version:    0.7.0.1
 */