package android.support.v4.view;

import android.graphics.Rect;
import android.view.View;

class ViewCompatJellybeanMr2
{
  public static Rect getClipBounds(View paramView)
  {
    return paramView.getClipBounds();
  }
  
  public static void setClipBounds(View paramView, Rect paramRect)
  {
    paramView.setClipBounds(paramRect);
  }
}


/* Location:           C:\Users\Vishal\Desktop\Android\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.view.ViewCompatJellybeanMr2
 * JD-Core Version:    0.7.0.1
 */