package android.support.v4.view;

import android.view.ViewConfiguration;

class ViewConfigurationCompatICS
{
  static boolean hasPermanentMenuKey(ViewConfiguration paramViewConfiguration)
  {
    return paramViewConfiguration.hasPermanentMenuKey();
  }
}


/* Location:           C:\Users\Vishal\Desktop\Android\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.view.ViewConfigurationCompatICS
 * JD-Core Version:    0.7.0.1
 */