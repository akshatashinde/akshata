package android.support.v4.widget;

import android.graphics.drawable.Drawable;
import android.widget.CompoundButton;

class CompoundButtonCompatApi23
{
  static Drawable getButtonDrawable(CompoundButton paramCompoundButton)
  {
    return paramCompoundButton.getButtonDrawable();
  }
}


/* Location:           C:\Users\Vishal\Desktop\Android\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.widget.CompoundButtonCompatApi23
 * JD-Core Version:    0.7.0.1
 */