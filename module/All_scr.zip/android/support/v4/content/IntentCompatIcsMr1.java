package android.support.v4.content;

import android.content.Intent;

class IntentCompatIcsMr1
{
  public static Intent makeMainSelectorActivity(String paramString1, String paramString2)
  {
    return Intent.makeMainSelectorActivity(paramString1, paramString2);
  }
}


/* Location:           C:\Users\Vishal\Desktop\Android\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.content.IntentCompatIcsMr1
 * JD-Core Version:    0.7.0.1
 */