package com.google.ads.mediation.customevent;

@Deprecated
public abstract interface CustomEvent
{
  public abstract void destroy();
}


/* Location:           C:\Users\Vishal\Desktop\Android\classes_dex2jar.jar
 * Qualified Name:     com.google.ads.mediation.customevent.CustomEvent
 * JD-Core Version:    0.7.0.1
 */