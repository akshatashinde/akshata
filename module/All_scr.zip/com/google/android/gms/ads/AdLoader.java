package com.google.android.gms.ads;

import android.content.Context;
import android.os.RemoteException;
import com.google.android.gms.ads.doubleclick.PublisherAdRequest;
import com.google.android.gms.ads.formats.NativeAdOptions;
import com.google.android.gms.ads.formats.NativeAppInstallAd.OnAppInstallAdLoadedListener;
import com.google.android.gms.ads.formats.NativeContentAd.OnContentAdLoadedListener;
import com.google.android.gms.ads.formats.NativeCustomTemplateAd.OnCustomClickListener;
import com.google.android.gms.ads.formats.NativeCustomTemplateAd.OnCustomTemplateAdLoadedListener;
import com.google.android.gms.ads.internal.client.zzc;
import com.google.android.gms.ads.internal.client.zzd;
import com.google.android.gms.ads.internal.client.zzh;
import com.google.android.gms.ads.internal.client.zzp;
import com.google.android.gms.ads.internal.client.zzq;
import com.google.android.gms.ads.internal.client.zzy;
import com.google.android.gms.ads.internal.formats.NativeAdOptionsParcel;
import com.google.android.gms.ads.internal.util.client.zzb;
import com.google.android.gms.internal.zzcy;
import com.google.android.gms.internal.zzdb;
import com.google.android.gms.internal.zzdc;
import com.google.android.gms.internal.zzdd;
import com.google.android.gms.internal.zzde;
import com.google.android.gms.internal.zzel;

public class AdLoader
{
  private final Context mContext;
  private final zzh zznL;
  private final zzp zznM;
  
  AdLoader(Context paramContext, zzp paramzzp)
  {
    this(paramContext, paramzzp, zzh.zzcB());
  }
  
  AdLoader(Context paramContext, zzp paramzzp, zzh paramzzh)
  {
    this.mContext = paramContext;
    this.zznM = paramzzp;
    this.zznL = paramzzh;
  }
  
  private void zza(zzy paramzzy)
  {
    try
    {
      this.zznM.zzf(this.zznL.zza(this.mContext, paramzzy));
      return;
    }
    catch (RemoteException localRemoteException)
    {
      zzb.zzb("Failed to load ad.", localRemoteException);
    }
  }
  
  public String getMediationAdapterClassName()
  {
    try
    {
      String str = this.zznM.getMediationAdapterClassName();
      return str;
    }
    catch (RemoteException localRemoteException)
    {
      zzb.zzd("Failed to get the mediation adapter class name.", localRemoteException);
    }
    return null;
  }
  
  public boolean isLoading()
  {
    try
    {
      boolean bool = this.zznM.isLoading();
      return bool;
    }
    catch (RemoteException localRemoteException)
    {
      zzb.zzd("Failed to check if ad is loading.", localRemoteException);
    }
    return false;
  }
  
  public void loadAd(AdRequest paramAdRequest)
  {
    zza(paramAdRequest.zzaF());
  }
  
  public void loadAd(PublisherAdRequest paramPublisherAdRequest)
  {
    zza(paramPublisherAdRequest.zzaF());
  }
  
  public static class Builder
  {
    private final Context mContext;
    private final zzq zznN;
    
    Builder(Context paramContext, zzq paramzzq)
    {
      this.mContext = paramContext;
      this.zznN = paramzzq;
    }
    
    public Builder(Context paramContext, String paramString)
    {
      this(paramContext, zzd.zza(paramContext, paramString, new zzel()));
    }
    
    public AdLoader build()
    {
      try
      {
        AdLoader localAdLoader = new AdLoader(this.mContext, this.zznN.zzbk());
        return localAdLoader;
      }
      catch (RemoteException localRemoteException)
      {
        zzb.zzb("Failed to build AdLoader.", localRemoteException);
      }
      return null;
    }
    
    public Builder forAppInstallAd(NativeAppInstallAd.OnAppInstallAdLoadedListener paramOnAppInstallAdLoadedListener)
    {
      try
      {
        this.zznN.zza(new zzdb(paramOnAppInstallAdLoadedListener));
        return this;
      }
      catch (RemoteException localRemoteException)
      {
        zzb.zzd("Failed to add app install ad listener", localRemoteException);
      }
      return this;
    }
    
    public Builder forContentAd(NativeContentAd.OnContentAdLoadedListener paramOnContentAdLoadedListener)
    {
      try
      {
        this.zznN.zza(new zzdc(paramOnContentAdLoadedListener));
        return this;
      }
      catch (RemoteException localRemoteException)
      {
        zzb.zzd("Failed to add content ad listener", localRemoteException);
      }
      return this;
    }
    
    public Builder forCustomTemplateAd(String paramString, NativeCustomTemplateAd.OnCustomTemplateAdLoadedListener paramOnCustomTemplateAdLoadedListener, NativeCustomTemplateAd.OnCustomClickListener paramOnCustomClickListener)
    {
      try
      {
        zzq localzzq = this.zznN;
        zzde localzzde = new zzde(paramOnCustomTemplateAdLoadedListener);
        if (paramOnCustomClickListener == null) {}
        for (Object localObject = null;; localObject = new zzdd(paramOnCustomClickListener))
        {
          localzzq.zza(paramString, localzzde, (zzcy)localObject);
          return this;
        }
        return this;
      }
      catch (RemoteException localRemoteException)
      {
        zzb.zzd("Failed to add custom template ad listener", localRemoteException);
      }
    }
    
    public Builder withAdListener(AdListener paramAdListener)
    {
      try
      {
        this.zznN.zzb(new zzc(paramAdListener));
        return this;
      }
      catch (RemoteException localRemoteException)
      {
        zzb.zzd("Failed to set AdListener.", localRemoteException);
      }
      return this;
    }
    
    public Builder withNativeAdOptions(NativeAdOptions paramNativeAdOptions)
    {
      try
      {
        this.zznN.zza(new NativeAdOptionsParcel(paramNativeAdOptions));
        return this;
      }
      catch (RemoteException localRemoteException)
      {
        zzb.zzd("Failed to specify native ad options", localRemoteException);
      }
      return this;
    }
  }
}


/* Location:           C:\Users\Vishal\Desktop\Android\classes_dex2jar.jar
 * Qualified Name:     com.google.android.gms.ads.AdLoader
 * JD-Core Version:    0.7.0.1
 */