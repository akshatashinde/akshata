package com.google.android.gms.ads.doubleclick;

public abstract interface OnCustomRenderedAdLoadedListener
{
  public abstract void onCustomRenderedAdLoaded(CustomRenderedAd paramCustomRenderedAd);
}


/* Location:           C:\Users\Vishal\Desktop\Android\classes_dex2jar.jar
 * Qualified Name:     com.google.android.gms.ads.doubleclick.OnCustomRenderedAdLoadedListener
 * JD-Core Version:    0.7.0.1
 */