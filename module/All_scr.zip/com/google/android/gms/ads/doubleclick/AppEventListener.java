package com.google.android.gms.ads.doubleclick;

public abstract interface AppEventListener
{
  public abstract void onAppEvent(String paramString1, String paramString2);
}


/* Location:           C:\Users\Vishal\Desktop\Android\classes_dex2jar.jar
 * Qualified Name:     com.google.android.gms.ads.doubleclick.AppEventListener
 * JD-Core Version:    0.7.0.1
 */