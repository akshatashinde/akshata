package com.google.android.gms.ads.purchase;

public abstract interface InAppPurchaseListener
{
  public abstract void onInAppPurchaseRequested(InAppPurchase paramInAppPurchase);
}


/* Location:           C:\Users\Vishal\Desktop\Android\classes_dex2jar.jar
 * Qualified Name:     com.google.android.gms.ads.purchase.InAppPurchaseListener
 * JD-Core Version:    0.7.0.1
 */