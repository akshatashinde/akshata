package com.google.android.gms.ads.mediation;

@Deprecated
public abstract interface NetworkExtras {}


/* Location:           C:\Users\Vishal\Desktop\Android\classes_dex2jar.jar
 * Qualified Name:     com.google.android.gms.ads.mediation.NetworkExtras
 * JD-Core Version:    0.7.0.1
 */