package com.google.android.gms.ads.internal;

import android.view.View;

public abstract interface zzg
{
  public abstract void recordClick();
  
  public abstract void recordImpression();
  
  public abstract void zzc(View paramView);
}


/* Location:           C:\Users\Vishal\Desktop\Android\classes_dex2jar.jar
 * Qualified Name:     com.google.android.gms.ads.internal.zzg
 * JD-Core Version:    0.7.0.1
 */