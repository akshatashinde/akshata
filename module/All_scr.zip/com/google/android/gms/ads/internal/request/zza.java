package com.google.android.gms.ads.internal.request;

import android.content.Context;
import android.os.Bundle;
import com.google.android.gms.ads.internal.client.AdRequestParcel;
import com.google.android.gms.internal.zzan;
import com.google.android.gms.internal.zzgr;
import com.google.android.gms.internal.zzhs.zza;
import com.google.android.gms.internal.zzhz;

@zzgr
public class zza
{
  public zzhz zza(Context paramContext, AdRequestInfoParcel.zza paramzza, zzan paramzzan, zza paramzza1)
  {
    if (paramzza.zzEn.extras.getBundle("sdk_less_server_data") != null) {}
    for (Object localObject = new zzm(paramContext, paramzza, paramzza1);; localObject = new zzb(paramContext, paramzza, paramzzan, paramzza1))
    {
      ((zzhz)localObject).zzgz();
      return localObject;
    }
  }
  
  public static abstract interface zza
  {
    public abstract void zza(zzhs.zza paramzza);
  }
}


/* Location:           C:\Users\Vishal\Desktop\Android\classes_dex2jar.jar
 * Qualified Name:     com.google.android.gms.ads.internal.request.zza
 * JD-Core Version:    0.7.0.1
 */