package com.google.android.gms.ads.internal.purchase;

import com.google.android.gms.internal.zzgr;

@zzgr
public final class zzf
{
  public long zzCQ;
  public final String zzCR;
  public final String zzCS;
  
  public zzf(long paramLong, String paramString1, String paramString2)
  {
    this.zzCQ = paramLong;
    this.zzCS = paramString1;
    this.zzCR = paramString2;
  }
  
  public zzf(String paramString1, String paramString2)
  {
    this(-1L, paramString1, paramString2);
  }
}


/* Location:           C:\Users\Vishal\Desktop\Android\classes_dex2jar.jar
 * Qualified Name:     com.google.android.gms.ads.internal.purchase.zzf
 * JD-Core Version:    0.7.0.1
 */