package com.google.android.gms.ads.internal;

import com.google.android.gms.ads.internal.overlay.zzj;
import com.google.android.gms.ads.internal.overlay.zzl;
import com.google.android.gms.internal.zzdh;
import com.google.android.gms.internal.zzdx;

public class zzd
{
  public final zzdx zzoG;
  public final zzj zzoH;
  
  public zzd(zzdx paramzzdx, zzj paramzzj)
  {
    this.zzoG = paramzzdx;
    this.zzoH = paramzzj;
  }
  
  public static zzd zzbd()
  {
    return new zzd(new zzdh(), new zzl());
  }
}


/* Location:           C:\Users\Vishal\Desktop\Android\classes_dex2jar.jar
 * Qualified Name:     com.google.android.gms.ads.internal.zzd
 * JD-Core Version:    0.7.0.1
 */