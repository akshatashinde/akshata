package com.google.android.gms.ads.internal.overlay;

public abstract interface zzg
{
  public abstract void zzaV();
  
  public abstract void zzaW();
}


/* Location:           C:\Users\Vishal\Desktop\Android\classes_dex2jar.jar
 * Qualified Name:     com.google.android.gms.ads.internal.overlay.zzg
 * JD-Core Version:    0.7.0.1
 */