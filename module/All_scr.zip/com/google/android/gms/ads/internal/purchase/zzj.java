package com.google.android.gms.ads.internal.purchase;

import android.content.Intent;

public abstract interface zzj
{
  public abstract void zza(String paramString, boolean paramBoolean, int paramInt, Intent paramIntent, zzf paramzzf);
}


/* Location:           C:\Users\Vishal\Desktop\Android\classes_dex2jar.jar
 * Qualified Name:     com.google.android.gms.ads.internal.purchase.zzj
 * JD-Core Version:    0.7.0.1
 */