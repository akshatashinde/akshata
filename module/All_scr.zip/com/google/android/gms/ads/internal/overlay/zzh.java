package com.google.android.gms.ads.internal.overlay;

public abstract interface zzh
{
  public abstract void onPaused();
  
  public abstract void zzeQ();
  
  public abstract void zzeR();
  
  public abstract void zzeS();
  
  public abstract void zzeT();
  
  public abstract void zzeU();
  
  public abstract void zzh(String paramString1, String paramString2);
}


/* Location:           C:\Users\Vishal\Desktop\Android\classes_dex2jar.jar
 * Qualified Name:     com.google.android.gms.ads.internal.overlay.zzh
 * JD-Core Version:    0.7.0.1
 */