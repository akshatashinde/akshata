package com.google.android.gms.ads.internal.client;

public abstract interface zza
{
  public abstract void onAdClicked();
}


/* Location:           C:\Users\Vishal\Desktop\Android\classes_dex2jar.jar
 * Qualified Name:     com.google.android.gms.ads.internal.client.zza
 * JD-Core Version:    0.7.0.1
 */