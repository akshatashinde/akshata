package com.google.android.gms.ads.internal.client;

public class zzac
{
  public String getTrackingId()
  {
    return null;
  }
  
  public boolean isGoogleAnalyticsEnabled()
  {
    return false;
  }
  
  public void zzO(String paramString) {}
  
  public void zzk(boolean paramBoolean) {}
}


/* Location:           C:\Users\Vishal\Desktop\Android\classes_dex2jar.jar
 * Qualified Name:     com.google.android.gms.ads.internal.client.zzac
 * JD-Core Version:    0.7.0.1
 */