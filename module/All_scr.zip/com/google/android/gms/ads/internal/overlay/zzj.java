package com.google.android.gms.ads.internal.overlay;

import android.content.Context;
import com.google.android.gms.internal.zzce;
import com.google.android.gms.internal.zzcg;
import com.google.android.gms.internal.zziz;

public abstract interface zzj
{
  public abstract zzi zza(Context paramContext, zziz paramzziz, int paramInt, zzcg paramzzcg, zzce paramzzce);
}


/* Location:           C:\Users\Vishal\Desktop\Android\classes_dex2jar.jar
 * Qualified Name:     com.google.android.gms.ads.internal.overlay.zzj
 * JD-Core Version:    0.7.0.1
 */