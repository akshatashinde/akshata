package com.google.android.gms.actions;

public class ReserveIntents
{
  public static final String ACTION_RESERVE_TAXI_RESERVATION = "com.google.android.gms.actions.RESERVE_TAXI_RESERVATION";
}


/* Location:           C:\Users\Vishal\Desktop\Android\classes_dex2jar.jar
 * Qualified Name:     com.google.android.gms.actions.ReserveIntents
 * JD-Core Version:    0.7.0.1
 */