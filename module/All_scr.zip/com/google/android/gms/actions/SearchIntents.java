package com.google.android.gms.actions;

public class SearchIntents
{
  public static final String ACTION_SEARCH = "com.google.android.gms.actions.SEARCH_ACTION";
  public static final String EXTRA_QUERY = "query";
}


/* Location:           C:\Users\Vishal\Desktop\Android\classes_dex2jar.jar
 * Qualified Name:     com.google.android.gms.actions.SearchIntents
 * JD-Core Version:    0.7.0.1
 */