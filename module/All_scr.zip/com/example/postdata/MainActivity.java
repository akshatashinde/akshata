package com.example.postdata;

import android.app.Activity;
import android.app.FragmentManager;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.List;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONObject;

public class MainActivity
  extends Activity
{
  GoogleMap amap;
  Button bt;
  String flag = "0";
  double lat;
  double lng;
  MyLocationListener locationlistener;
  LocationManager locationmanager;
  Button rbt;
  String responseServer;
  TextView txt;
  
  public void getGpsData()
  {
    try
    {
      Location localLocation = this.locationmanager.getLastKnownLocation("gps");
      if (localLocation != null)
      {
        this.lat = localLocation.getLatitude();
        this.lng = localLocation.getLongitude();
      }
      return;
    }
    catch (Exception localException) {}
  }
  
  protected void onCreate(Bundle paramBundle)
  {
    super.onCreate(paramBundle);
    setContentView(2130903040);
    this.txt = ((TextView)findViewById(2131165216));
    this.bt = ((Button)findViewById(2131165217));
    this.rbt = ((Button)findViewById(2131165218));
    this.amap = ((MapFragment)getFragmentManager().findFragmentById(2131165219)).getMap();
    this.amap.clear();
    this.amap.setMapType(1);
    this.amap.setMyLocationEnabled(true);
    try
    {
      this.locationmanager = ((LocationManager)getSystemService("location"));
      this.locationlistener = new MyLocationListener();
      this.locationmanager.requestLocationUpdates("gps", 100L, 100.0F, this.locationlistener);
      if (!this.locationmanager.isProviderEnabled("gps")) {
        Toast.makeText(getApplicationContext(), "Please on GPS!", 0).show();
      }
      for (;;)
      {
        this.locationmanager = ((LocationManager)getSystemService("location"));
        Criteria localCriteria = new Criteria();
        String str = this.locationmanager.getBestProvider(localCriteria, true);
        Location localLocation = this.locationmanager.getLastKnownLocation(str);
        double d1 = localLocation.getLatitude();
        double d2 = localLocation.getLongitude();
        MarkerOptions localMarkerOptions = new MarkerOptions().position(new LatLng(d1, d2)).title("You are Here!");
        localMarkerOptions.icon(BitmapDescriptorFactory.defaultMarker(120.0F));
        this.amap.addMarker(localMarkerOptions);
        this.amap.animateCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(d1, d2), 12.0F));
        new AsyncT().execute(new Void[0]);
        this.rbt.setOnClickListener(new View.OnClickListener()
        {
          public void onClick(View paramAnonymousView)
          {
            new MainActivity.Getfromserver(MainActivity.this).execute(new Void[0]);
          }
        });
        return;
        getGpsData();
      }
    }
    catch (Exception localException)
    {
      for (;;)
      {
        System.out.println("----Error Starting Location Manager");
      }
    }
  }
  
  class AsyncT
    extends AsyncTask<Void, Void, Void>
  {
    Criteria criteria = new Criteria();
    double lat = this.mylocation.getLatitude();
    double lng = this.mylocation.getLongitude();
    LocationManager locationmanager = (LocationManager)MainActivity.this.getSystemService("location");
    Location mylocation = this.locationmanager.getLastKnownLocation(this.provider);
    String provider = this.locationmanager.getBestProvider(this.criteria, true);
    
    AsyncT() {}
    
    protected Void doInBackground(Void... paramVarArgs)
    {
      String str1 = this.lat;
      String str2 = this.lng;
      DefaultHttpClient localDefaultHttpClient = new DefaultHttpClient();
      HttpPost localHttpPost = new HttpPost("http://192.168.0.103:8000/api/get/location/");
      try
      {
        new JSONObject();
        ArrayList localArrayList = new ArrayList();
        localArrayList.add(new BasicNameValuePair("latitude", str1));
        localArrayList.add(new BasicNameValuePair("longitude", str2));
        Log.i("mainToPost", "mainToPost" + localArrayList.toString());
        localHttpPost.setEntity(new UrlEncodedFormEntity(localArrayList));
        InputStream localInputStream = localDefaultHttpClient.execute(localHttpPost).getEntity().getContent();
        new MainActivity.InputStreamToStringExample();
        MainActivity.this.responseServer = MainActivity.InputStreamToStringExample.access$0(localInputStream);
        Log.i("response", "response -----" + MainActivity.this.responseServer);
        return null;
      }
      catch (Exception localException)
      {
        for (;;)
        {
          localException.printStackTrace();
        }
      }
    }
    
    protected void onPostExecute(Void paramVoid)
    {
      super.onPostExecute(paramVoid);
      MainActivity.this.txt.setText(MainActivity.this.responseServer);
    }
  }
  
  class Getfromserver
    extends AsyncTask<Void, Void, Void>
  {
    private String Content;
    private final HttpClient httpclient = new DefaultHttpClient();
    
    Getfromserver() {}
    
    protected Void doInBackground(Void... paramVarArgs)
    {
      try
      {
        HttpGet localHttpGet = new HttpGet("http://192.168.0.103:8000/api/put/location/");
        BasicResponseHandler localBasicResponseHandler = new BasicResponseHandler();
        this.Content = ((String)this.httpclient.execute(localHttpGet, localBasicResponseHandler));
        InputStream localInputStream = this.httpclient.execute(localHttpGet).getEntity().getContent();
        new MainActivity.InputStreamToStringExample();
        MainActivity.this.responseServer = MainActivity.InputStreamToStringExample.access$0(localInputStream);
        Log.i("response", "response -----" + MainActivity.this.responseServer);
        return null;
      }
      catch (ClientProtocolException localClientProtocolException)
      {
        for (;;)
        {
          localClientProtocolException.printStackTrace();
        }
      }
      catch (IOException localIOException)
      {
        for (;;)
        {
          localIOException.printStackTrace();
        }
      }
    }
    
    protected void onPostExecute(Void paramVoid)
    {
      super.onPostExecute(paramVoid);
      MainActivity.this.txt.setText(MainActivity.this.responseServer);
    }
  }
  
  public static class InputStreamToStringExample
  {
    /* Error */
    private static String getStringFromInputStream(InputStream paramInputStream)
    {
      // Byte code:
      //   0: aconst_null
      //   1: astore_1
      //   2: new 17	java/lang/StringBuilder
      //   5: dup
      //   6: invokespecial 18	java/lang/StringBuilder:<init>	()V
      //   9: astore_2
      //   10: new 20	java/io/BufferedReader
      //   13: dup
      //   14: new 22	java/io/InputStreamReader
      //   17: dup
      //   18: aload_0
      //   19: invokespecial 25	java/io/InputStreamReader:<init>	(Ljava/io/InputStream;)V
      //   22: invokespecial 28	java/io/BufferedReader:<init>	(Ljava/io/Reader;)V
      //   25: astore_3
      //   26: aload_3
      //   27: invokevirtual 32	java/io/BufferedReader:readLine	()Ljava/lang/String;
      //   30: astore 8
      //   32: aload 8
      //   34: ifnonnull +16 -> 50
      //   37: aload_3
      //   38: ifnull +82 -> 120
      //   41: aload_3
      //   42: invokevirtual 35	java/io/BufferedReader:close	()V
      //   45: aload_2
      //   46: invokevirtual 38	java/lang/StringBuilder:toString	()Ljava/lang/String;
      //   49: areturn
      //   50: aload_2
      //   51: aload 8
      //   53: invokevirtual 42	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   56: pop
      //   57: goto -31 -> 26
      //   60: astore 6
      //   62: aload_3
      //   63: astore_1
      //   64: aload 6
      //   66: invokevirtual 45	java/io/IOException:printStackTrace	()V
      //   69: aload_1
      //   70: ifnull -25 -> 45
      //   73: aload_1
      //   74: invokevirtual 35	java/io/BufferedReader:close	()V
      //   77: goto -32 -> 45
      //   80: astore 7
      //   82: aload 7
      //   84: invokevirtual 45	java/io/IOException:printStackTrace	()V
      //   87: goto -42 -> 45
      //   90: astore 4
      //   92: aload_1
      //   93: ifnull +7 -> 100
      //   96: aload_1
      //   97: invokevirtual 35	java/io/BufferedReader:close	()V
      //   100: aload 4
      //   102: athrow
      //   103: astore 5
      //   105: aload 5
      //   107: invokevirtual 45	java/io/IOException:printStackTrace	()V
      //   110: goto -10 -> 100
      //   113: astore 10
      //   115: aload 10
      //   117: invokevirtual 45	java/io/IOException:printStackTrace	()V
      //   120: goto -75 -> 45
      //   123: astore 4
      //   125: aload_3
      //   126: astore_1
      //   127: goto -35 -> 92
      //   130: astore 6
      //   132: aconst_null
      //   133: astore_1
      //   134: goto -70 -> 64
      // Local variable table:
      //   start	length	slot	name	signature
      //   0	137	0	paramInputStream	InputStream
      //   1	133	1	localObject1	Object
      //   9	42	2	localStringBuilder	java.lang.StringBuilder
      //   25	101	3	localBufferedReader	java.io.BufferedReader
      //   90	11	4	localObject2	Object
      //   123	1	4	localObject3	Object
      //   103	3	5	localIOException1	IOException
      //   60	5	6	localIOException2	IOException
      //   130	1	6	localIOException3	IOException
      //   80	3	7	localIOException4	IOException
      //   30	22	8	str	String
      //   113	3	10	localIOException5	IOException
      // Exception table:
      //   from	to	target	type
      //   26	32	60	java/io/IOException
      //   50	57	60	java/io/IOException
      //   73	77	80	java/io/IOException
      //   10	26	90	finally
      //   64	69	90	finally
      //   96	100	103	java/io/IOException
      //   41	45	113	java/io/IOException
      //   26	32	123	finally
      //   50	57	123	finally
      //   10	26	130	java/io/IOException
    }
    
    public static void main(String[] paramArrayOfString)
      throws IOException
    {
      String str = getStringFromInputStream(new ByteArrayInputStream("file content..blah blah".getBytes()));
      System.out.println(str);
      System.out.println("Done");
    }
  }
  
  public class MyLocationListener
    implements LocationListener
  {
    public MyLocationListener() {}
    
    public void onLocationChanged(Location paramLocation)
    {
      MainActivity.this.lat = paramLocation.getLatitude();
      MainActivity.this.lng = paramLocation.getLatitude();
    }
    
    public void onProviderDisabled(String paramString) {}
    
    public void onProviderEnabled(String paramString) {}
    
    public void onStatusChanged(String paramString, int paramInt, Bundle paramBundle) {}
  }
}


/* Location:           C:\Users\Vishal\Desktop\Android\classes_dex2jar.jar
 * Qualified Name:     com.example.postdata.MainActivity
 * JD-Core Version:    0.7.0.1
 */