package com.example.postdata;

public class AppConfig
{
  public static Double LATITUDE = Double.valueOf(0.0D);
  public static Double LONGITUDE = Double.valueOf(0.0D);
}


/* Location:           C:\Users\Vishal\Desktop\Android\classes_dex2jar.jar
 * Qualified Name:     com.example.postdata.AppConfig
 * JD-Core Version:    0.7.0.1
 */