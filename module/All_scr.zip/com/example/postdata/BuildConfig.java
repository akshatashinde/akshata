package com.example.postdata;

public final class BuildConfig
{
  public static final boolean DEBUG = true;
}


/* Location:           C:\Users\Vishal\Desktop\Android\classes_dex2jar.jar
 * Qualified Name:     com.example.postdata.BuildConfig
 * JD-Core Version:    0.7.0.1
 */